#' Exp
#'
#'
#' @details This function gives the estimation of exp(x) using Taylor expansion to k stages.

#' @param x number, value of exp(x) to be estimated;
#' @param k integer, stages of the calculation.
#'
#' @return The estimated value.
#'
#' @import devtools
#' @import roxygen2
#' @import ggplot2
#'
#' @export Exp
#'
#' @examples
#' Exp(1,5)
#'
Exp <- function(x, k) {
  prob1_value <- 1
  for (i in 1:k) {
    prob1_value <- prob1_value + (x^i)/factorial(i)
  }
  return(prob1_value)
}

#' @examples pm <- c(exp(rnorm(2000, mean = 3, sd = 1)),
#' exp(rnorm(2000, mean = 1, sd = 1.5)),
#' exp(rnorm(1000, mean = .5, sd = 1)))
#' plot_simulationCI(pm, 10)
