#' plot_simulationCI
#'
#'This function gives the confidence intervals with a subset of the data.
#'
#' @details This function bootstrap a subset of the data with the given size and then estimate the 95% confidence interval from t-distribution with the subset.

#' @param data vector, the values to estimate 95% confidence intervals from;
#' @param n integer, number of observations in the subset.
#'
#' @return The estimated confidence interval
#'
#' @import devtools
#' @import roxygen2
#' @import ggplot2
#' @import dplyr
#'
#' @export plot_simulationCI
#'
#' @examples pm <- c(exp(rnorm(2000, mean = 3, sd = 1)),
#' exp(rnorm(2000, mean = 1, sd = 1.5)),
#' exp(rnorm(1000, mean = .5, sd = 1)))
#' plot_simulationCI(pm, 10)

calculate_CI95 <- function(data){

  x <- sample(data,20,replace = T)
  smry <- c(mean(x) - 1.96 * sd(x)/sqrt(20), mean(x), mean(x) + 1.96 * sd(x)/sqrt(20))
  names(smry) <- c('lower', 'mean', 'upper')
  return(smry)
}
plot_simulationCI <- function(Data, n){
  x <- NULL
  for (i in 1:n) {
    x <- rbind(x,c(calculate_CI95(Data),i))
  }
  colnames(x)[4] <- 'sample.number'
  x <- data.frame(x)
  sample.number = x$sample.number
  lower = x$lower
  upper = x$upper
  x %>%
    ggplot(aes(sample.number,mean)) +
    geom_point() +
    geom_errorbar(aes(ymin = lower, ymax = upper))+
    labs(x = 'Sample Number', y = 'Value')
}
